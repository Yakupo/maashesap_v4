import { useState } from 'react';
import { calcHourlyRate, calcNoticePay, calcSeverancePay, calcYearsWorked } from '../utils/calculations';

const CURRENCY_OPTIONS = [
  { value: 'TRY', label: 'Türk Lirası (₺)' },
  { value: 'USD', label: 'Amerikan Doları ($)' },
  { value: 'EUR', label: 'Euro (€)' },
];

const THEME_OPTIONS = [
  { value: 'light', label: 'Açık Tema' },
  { value: 'dark', label: 'Koyu Tema' },
];

const LANG_OPTIONS = [
  { value: 'tr', label: 'Türkçe' },
  { value: 'en', label: 'English' },
];

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">{label}</label>
      {children}
    </div>
  );
}

function Input({ value, onChange, type = 'number', step, min }) {
  return (
    <input
      type={type}
      step={step}
      min={min}
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full border border-gray-200 dark:border-gray-600 rounded-xl px-4 py-3 text-gray-800 dark:text-gray-100 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
    />
  );
}

function Select({ value, onChange, options }) {
  return (
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full border border-gray-200 dark:border-gray-600 rounded-xl px-4 py-3 text-gray-800 dark:text-gray-100 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
    >
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

function InfoCard({ label, value }) {
  return (
    <div className="bg-blue-50 dark:bg-gray-700 rounded-xl p-3">
      <div className="text-xs text-gray-500 dark:text-gray-400">{label}</div>
      <div className="text-base font-bold text-gray-800 dark:text-gray-100 mt-0.5">{value}</div>
    </div>
  );
}

function fmt(n) {
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
}

export default function SettingsModal({ settings, onSave, onClose }) {
  const [form, setForm] = useState({ ...settings });

  function set(key, val) {
    setForm(prev => ({ ...prev, [key]: val }));
  }

  const hourly = calcHourlyRate(+form.monthlySalary, +form.dailyWorkHours);
  const daily = hourly * +form.dailyWorkHours;
  const weekly = daily * 5;
  const yearly = +form.monthlySalary * 12;
  const severance = calcSeverancePay(form.monthlySalary, form.startDate);
  const notice = calcNoticePay(form.monthlySalary, form.startDate);
  const years = calcYearsWorked(form.startDate);

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-sm shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-100 dark:border-gray-700 shrink-0">
          <div className="flex items-center gap-2 text-gray-800 dark:text-gray-100 font-semibold text-lg">
            <span>⚙️</span>
            <span>Ayarlar ve Hesaplamalar</span>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">✕</button>
        </div>

        {/* Scrollable body */}
        <div className="overflow-y-auto flex-1 p-5 space-y-5">
          {/* Maaş Ayarları */}
          <div>
            <div className="flex items-center gap-2 text-gray-700 dark:text-gray-200 font-semibold mb-3">
              <span>💲</span><span>Maaş ve Mesai Ayarları</span>
            </div>
            <div className="space-y-3">
              <Field label="Para Birimi">
                <Select value={form.currency} onChange={v => set('currency', v)} options={CURRENCY_OPTIONS} />
              </Field>
              <Field label="Aylık Maaş">
                <Input value={form.monthlySalary} onChange={v => set('monthlySalary', v)} min="0" />
              </Field>
              <Field label="Hafta İçi Mesai Katsayısı">
                <Input value={form.weekdayMultiplier} onChange={v => set('weekdayMultiplier', v)} step="0.1" min="1" />
              </Field>
              <Field label="Cumartesi Mesai Katsayısı">
                <Input value={form.saturdayMultiplier} onChange={v => set('saturdayMultiplier', v)} step="0.1" min="1" />
              </Field>
              <Field label="Pazar Mesai Katsayısı">
                <Input value={form.sundayMultiplier} onChange={v => set('sundayMultiplier', v)} step="0.1" min="1" />
              </Field>
              <Field label="Bayram Mesai Katsayısı">
                <Input value={form.holidayMultiplier ?? 2} onChange={v => set("holidayMultiplier", v)} step="0.1" min="1" />
              </Field>
              <Field label="Günlük Çalışma Saati">
                <Input value={form.dailyWorkHours} onChange={v => set('dailyWorkHours', v)} step="0.5" min="1" />
              </Field>
            </div>
          </div>

          {/* Hesaplamalar */}
          <div>
            <div className="flex items-center gap-2 text-gray-700 dark:text-gray-200 font-semibold mb-3">
              <span>🧮</span><span>Maaş Hesaplamaları</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <InfoCard label="Saatlik Ücret" value={`₺${fmt(hourly)}`} />
              <InfoCard label="Günlük Ücret" value={`₺${fmt(daily)}`} />
              <InfoCard label="Haftalık Ücret" value={`₺${fmt(weekly)}`} />
              <InfoCard label="Yıllık Ücret" value={`₺${fmt(yearly)}`} />
            </div>
          </div>

          {/* Kıdem & İhbar */}
          <div>
            <Field label="Çalışma Süresi (Yıl)">
              <Input value={form.yearsWorked} onChange={v => set('yearsWorked', v)} min="0" step="0.5" />
            </Field>
            <div className="grid grid-cols-2 gap-2 mt-3">
              <InfoCard label="Kıdem Tazminatı" value={`₺${fmt(severance)}`} />
              <InfoCard label="İhbar Tazminatı" value={`₺${fmt(notice)}`} />
            </div>
          </div>

          {/* Görünüm */}
          <div>
            <div className="flex items-center gap-2 text-gray-700 dark:text-gray-200 font-semibold mb-3">
              <span>🎨</span><span>Görünüm Ayarları</span>
            </div>
            <div className="space-y-3">
              <Field label="Tema">
                <Select value={form.theme} onChange={v => set('theme', v)} options={THEME_OPTIONS} />
              </Field>
              <Field label="Dil">
                <Select value={form.language} onChange={v => set('language', v)} options={LANG_OPTIONS} />
              </Field>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex gap-3 p-5 border-t border-gray-100 dark:border-gray-700 shrink-0">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-300 font-semibold hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            İptal
          </button>
          <button
            onClick={() => { onSave(form); onClose(); }}
            className="flex-1 py-3 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700"
          >
            Kaydet
          </button>
        </div>
      </div>
    </div>
  );
}
