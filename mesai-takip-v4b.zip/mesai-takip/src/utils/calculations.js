import { getHolidayInfo } from './holidays';

export function calcHourlyRate(monthlySalary, dailyWorkHours) {
  const s = Number(monthlySalary);
  const h = Number(dailyWorkHours);
  if (!s || !h) return 0;
  return s / (30 * h);
}

export function calcOvertimePay(dateStr, hours, status, settings) {
  const date = new Date(dateStr);
  const day = date.getDay();
  const hourlyRate = calcHourlyRate(settings.monthlySalary, settings.dailyWorkHours);

  let multiplier;
  if (status === 'bayram_mesai') {
    multiplier = Number(settings.holidayMultiplier) || 2;
  } else if (day === 6) {
    multiplier = Number(settings.saturdayMultiplier) || 1.5;
  } else if (day === 0) {
    multiplier = Number(settings.sundayMultiplier) || 2;
  } else {
    multiplier = Number(settings.weekdayMultiplier) || 1.5;
  }

  return Number(hours) * hourlyRate * multiplier;
}

export function calcMonthSummary(year, month, attendance, settings) {
  let totalOvertimeHours = 0;
  let totalOvertimePay = 0;
  let totalDeductions = 0;

  const salary = Number(settings.monthlySalary) || 0;
  const dailyRate = salary / 30;

  Object.entries(attendance).forEach(([dateStr, record]) => {
    const d = new Date(dateStr);
    if (d.getFullYear() === year && d.getMonth() === month) {
      if (record.status === 'mesaide' || record.status === 'bayram_mesai') {
        totalOvertimeHours += Number(record.overtimeHours) || 0;
        totalOvertimePay += calcOvertimePay(dateStr, record.overtimeHours || 0, record.status, settings);
      } else if (record.status === 'devamsiz') {
        totalDeductions += dailyRate;
      }
    }
  });

  return {
    totalOvertimeHours,
    totalOvertimePay,
    monthlySalary: salary,
    deductions: totalDeductions,
    netSalary: salary + totalOvertimePay - totalDeductions,
  };
}

// İşe başlangıç tarihinden yıl hesapla
export function calcYearsWorked(startDate) {
  if (!startDate) return 0;
  const start = new Date(startDate);
  const now = new Date();
  const diff = now - start;
  return Math.max(0, diff / (1000 * 60 * 60 * 24 * 365.25));
}

export function calcSeverancePay(monthlySalary, startDate) {
  const years = calcYearsWorked(startDate);
  return Number(monthlySalary) * years;
}

export function calcNoticePay(monthlySalary, startDate) {
  const years = calcYearsWorked(startDate);
  let weeks = 2;
  if (years >= 6) weeks = 8;
  else if (years >= 3) weeks = 6;
  else if (years >= 1.5) weeks = 4;
  return (Number(monthlySalary) / 4) * weeks;
}
