import { getHolidayInfo } from './holidays';

export function calcHourlyRate(monthlySalary, dailyWorkHours) {
  const s = Number(monthlySalary);
  const h = Number(dailyWorkHours);
  if (!s || !h) return 0;
  return s / (30 * h);
}

export function calcOvertimePay(dateStr, hours, status, settings) {
  const date = new Date(dateStr);
  const day = date.getDay();
  const hourlyRate = calcHourlyRate(settings.monthlySalary, settings.dailyWorkHours);
  let multiplier;
  if (status === 'bayram_mesai') multiplier = Number(settings.holidayMultiplier) || 2;
  else if (day === 6) multiplier = Number(settings.saturdayMultiplier) || 1.5;
  else if (day === 0) multiplier = Number(settings.sundayMultiplier) || 2;
  else multiplier = Number(settings.weekdayMultiplier) || 1.5;
  return Number(hours) * hourlyRate * multiplier;
}

export function calcMonthSummary(year, month, attendance, settings) {
  let totalOvertimeHours = 0;
  let totalOvertimePay = 0;
  let totalDeductions = 0;
  const salary = Number(settings.monthlySalary) || 0;
  const dailyRate = salary / 30;

  Object.entries(attendance).forEach(([dateStr, record]) => {
    const d = new Date(dateStr);
    if (d.getFullYear() === year && d.getMonth() === month) {
      if (record.status === 'mesaide' || record.status === 'bayram_mesai') {
        totalOvertimeHours += Number(record.overtimeHours) || 0;
        totalOvertimePay += calcOvertimePay(dateStr, record.overtimeHours || 0, record.status, settings);
      } else if (record.status === 'devamsiz') {
        totalDeductions += dailyRate;
      }
    }
  });

  return {
    totalOvertimeHours,
    totalOvertimePay,
    monthlySalary: salary,
    deductions: totalDeductions,
    netSalary: salary + totalOvertimePay - totalDeductions,
  };
}

// Yıllık devamsızlık gün sayısı
export function calcYearlyAbsenceDays(year, attendance) {
  let count = 0;
  Object.entries(attendance).forEach(([dateStr, record]) => {
    const d = new Date(dateStr);
    if (d.getFullYear() === year && record.status === 'devamsiz') count++;
  });
  return count;
}

// Çalışma yılı (ondalıklı)
export function calcYearsWorked(startDate) {
  if (!startDate) return 0;
  const start = new Date(startDate);
  const now = new Date();
  return Math.max(0, (now - start) / (1000 * 60 * 60 * 24 * 365.25));
}

// Kıdem tazminatı
// MIN(brüt maaş, tavan) × tam yıl sayısı
export function calcSeverancePay(monthlySalary, startDate, severanceCap) {
  if (!startDate) return 0;
  const years = Math.floor(calcYearsWorked(startDate));
  const base = Math.min(Number(monthlySalary) || 0, Number(severanceCap) || Number(monthlySalary) || 0);
  return base * years;
}

// İhbar tazminatı
export function calcNoticePay(monthlySalary, startDate) {
  const years = calcYearsWorked(startDate);
  let weeks = 2;
  if (years >= 6) weeks = 8;
  else if (years >= 3) weeks = 6;
  else if (years >= 1.5) weeks = 4;
  return (Number(monthlySalary) / 4) * weeks;
}

// Doğum tarihini parse et (gg.mm.yyyy)
export function parseBirthDate(str) {
  if (!str) return null;
  const parts = str.split('.');
  if (parts.length !== 3) return null;
  const d = new Date(`${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`);
  return isNaN(d) ? null : d;
}

// Yaş hesapla
export function calcAge(birthDateStr) {
  const birth = parseBirthDate(birthDateStr);
  if (!birth) return 0;
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

// Yıllık izin hak edilen gün sayısı
export function calcAnnualLeaveDays(birthDateStr, startDate) {
  const age = calcAge(birthDateStr);
  const years = calcYearsWorked(startDate);
  if (age >= 50) return 21;
  if (years >= 5) return 21;
  return 14;
}

// Yıllık izin başlangıç tarihi
// mod: 'basit' | 'degisken'
// degisken modda o yılki devamsızlık günleri eklenir
export function calcLeaveStartDate(startDate, mode, absenceDays) {
  if (!startDate) return null;
  const start = new Date(startDate);
  // 1 yıl sonrası
  const leaveStart = new Date(start);
  leaveStart.setFullYear(leaveStart.getFullYear() + 1);
  if (mode === 'degisken' && absenceDays > 0) {
    leaveStart.setDate(leaveStart.getDate() + absenceDays);
  }
  return leaveStart;
}
